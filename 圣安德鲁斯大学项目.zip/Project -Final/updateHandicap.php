<?php
include("db.php");
if(isset($_POST['handicap'])&&($_POST['memberid']))
{
    $handicap = $_POST['handicap'];
    $memberid = $_POST['memberid'];
	
    $sql="INSERT INTO handicapHistory(memberid,Handicap)VALUES('$memberid','$handicap')";	
	$sql1 = "UPDATE Club_member SET Handicap ='$handicap' WHERE member_id='$memberid'";
	$result= mysql_query($sql);
	$result1 = mysql_query($sql1);

  }



?>