<?php
//Find errors of blank page;
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 'On');
 ob_start();
  include("db.php");
  if(isset($_POST['submit'])!="")
  {
 // $memberID=$_POST['memberID'];
  $competitionDate=$_POST['competitiondate'];
  $competitionName=$_POST['Competitionname'];
  
/*
  $idvalue = mysql_query("select last_insert_id()");
  echo $idvalue;
  */
  $update="INSERT INTO Competition1(Competition_Date,Competition_Name)VALUES
  ('$competitionDate','$competitionName')";	
//	echo $update;
	$result = mysql_query($update) or die(mysql_error());  	
 if($result)

  {
	echo'<script language ="javascript">';
	echo'alert("Successfully created!");location.href="viewCompetition.php"';
	echo'</script>';
  }
  //
  else
  {
	echo'<script language ="javascript">';
	echo'alert("Error!");location.href="viewCompetition.php"';
	echo'</script>';
  }
  }
?>