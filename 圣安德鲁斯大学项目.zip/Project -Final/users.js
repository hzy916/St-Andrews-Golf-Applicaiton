//add players to a competition
function addPlayerAction() {
if(confirm("Are you sure want to add these players to the same competition?")) {
//document.frmUser.action = "addplayer.php";
document.frmUser.action = "viewCompetition.php";
document.frmUser.submit();
//window.location.href = "viewCompetition.php";
}
}
//delete multiple members 
function setDeleteAction() {
if(confirm("Are you sure want to delete these rows?")) {
document.frmUser.action = "delete_user.php";

document.frmUser.submit();
}
}

//select a competition
function SelectCompetition() {
if(confirm("Are you sure want to add players to this competition?")) {
document.frm.action = "addplayer.php";
document.frm.submit();
}
}

function UpdateScratch(){
	document.Scoreform.action = "Scratch.php";
	
	
}
