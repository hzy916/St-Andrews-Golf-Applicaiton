
<?php
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 'On');
 ob_start();
 
 if( isset($_SESSION['user'])!="" ){
 header("Location: login.php");
}
 
 
  include("db.php");
 if(isset($_POST['register'])){
	 $adminname = trim($_POST['adminname']);
	 $uemail = trim ($_POST['uemail']);
     $password1 = trim($_POST['password1']);
	 $password2 = trim($_POST['password2']);
 
	 $adminname = strip_tags($adminname);
	 $uemail = strip_tags($uemail);
	 $password1 = strip_tags($password1);
	 
	// password encrypt using SHA256();
	$password = hash('sha256', $password1);
 
 
    // check email exist or not
	 $query = "SELECT ademail FROM Admin WHERE ademail='$uemail'";
	 $res = mysql_query($query);
	
	if($res === false){
		var_dump(mysql_error());
	 }else{
		 // print_r(mysql_num_rows($res));
	 }
	
	$count = mysql_num_rows($res); 
 
 
	 if ($count==0) {
	$update="INSERT INTO Admin(adname,ademail,adpassword)VALUES
	('$adminname','$uemail','$password1')";	
	
	$result = mysql_query($update) or die(mysql_error());  	
	 
	 if($result)

  { 
	echo'<script language ="javascript">';
	echo'alert("Successfully Registered! Please log in now.");';
	echo'location.href="login.php";';
	echo'</script>';
  }
  else
  {
	echo'<script language ="javascript">';
	echo'alert("Error!Please try again.");';
	echo'</script>';
  }
  }else{
	  echo'<script language ="javascript">';
	echo'alert("Sorry Email already in use, please sign up with another email.");';
	//echo'location.href="login.php";';
	echo'</script>';
  }
 }

?>