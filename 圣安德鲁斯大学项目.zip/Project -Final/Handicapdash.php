<?php
session_start();
if( !$_SESSION['login_user']){
header("location:login.php");
}

?>

<!doctype html>
<html class="no-js">
  <head>
    <meta charset="UTF-8">
    <title>Table</title>

    <!--IE Compatibility modes-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!--Mobile first-->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">

    <!-- Metis core stylesheet -->
    <link rel="stylesheet" href="assets/css/main.min.css">

    <!-- metisMenu stylesheet -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/metisMenu/1.1.3/metisMenu.min.css">
    <link rel="stylesheet" href="//cdn.datatables.net/plug-ins/3cfcc339e89/integration/bootstrap/3/dataTables.bootstrap.css">

	<script language="javascript" src="users.js" type="text/javascript"></script>
    <script>
      less = {
        env: "development",
        relativeUrls: false,
        rootpath: "../assets/"
      };
    </script>
    <link rel="stylesheet" href="assets/css/style-switcher.css">
    <link rel="stylesheet/less" type="text/css" href="assets/less/theme.less">
    <script src="//cdnjs.cloudflare.com/ajax/libs/less.js/2.2.0/less.min.js"></script>

    <script src="//cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
	
	<script type="text/javascript" src="d3.v3.js"></script>
<script src="d3.v3.min.js"></script>
<script src="Data.js"></script>
	<style>
#bargraph{
    position:relative;
    background-color:#e6faff;
	height:600px;
	width: 1000px;
    border:1px solid;
    text-align:center;
}

</style>
  </head>
  <body class="  ">
    <div class="bg-dark dk" id="wrap">
      <div id="top">

        <nav class="navbar navbar-inverse navbar-static-top">
          <div class="container-fluid">

            <!-- Brand and toggle get grouped for better mobile display -->
            <header class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                <span class="sr-only">Toggle navigation</span> 
                <span class="icon-bar"></span> 
                <span class="icon-bar"></span> 
                <span class="icon-bar"></span> 
              </button>
              <a href="memberList.php" class="navbar-brand">
                <!--STandrews Image-->
              </a> 
            </header>
            <div class="topnav">
              <div class="btn-group">
                <a data-placement="bottom" data-original-title="Fullscreen" data-toggle="tooltip" class="btn btn-default btn-sm" id="toggleFullScreen">
                  <i class="glyphicon glyphicon-fullscreen"></i>
                </a> 
              </div>
              <div class="btn-group">
                
                <a data-toggle="modal" data-original-title="Help" data-placement="bottom" class="btn btn-default btn-sm"   href="#helpModal">
                  <i class="fa fa-question" ></i>
				  
                </a> 
              </div>
              <div class="btn-group">
                <a href="login.php" data-toggle="tooltip" data-original-title="Logout" data-placement="bottom" class="btn btn-metis-1 btn-sm">
                  <i class="fa fa-power-off"></i>
                </a> 
              </div>
              <div class="btn-group">
                <a data-placement="bottom" data-original-title="Show / Hide Left" data-toggle="tooltip" class="btn btn-primary btn-sm toggle-left" id="menu-toggle">
                  <i class="fa fa-bars"></i>
                </a> 
                <a data-placement="bottom" data-original-title="Show / Hide Right" data-toggle="tooltip" class="btn btn-default btn-sm toggle-right"> <span class="glyphicon glyphicon-comment"></span>  </a> 
              </div>
            </div>
            <div class="collapse navbar-collapse navbar-ex1-collapse">

              <!-- .nav -->
              <ul class="nav navbar-nav">
                <li> <a href="logout.php">Log out</a>  </li>
                <li class="active">
                  <a href="">Report Dashboard</a> 
                </li>
                <li> <a href="fileManager.php">Archive Files</a>  </li>
                <li class='dropdown '>
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    View
                    <b class="caret"></b>
                  </a> 
                  <ul class="dropdown-menu">
                    <li> <a href="memberList.php">View all members</a>  </li>
                    <li> <a href="viewCompetition.php">View all competitions</a>  </li>
                 
             
                  </ul>
                </li>
              </ul><!-- /.nav -->
            </div>
          </div>
        </nav>
        <header class="head">
          <div class="search-bar">
           
          </div><!-- /.search-bar -->
          <div class="main-bar">
            <h3>
              <i class="fa fa-table"></i>&nbsp; Table</h3>
          </div><!-- /.main-bar -->
        </header><!-- /.head -->
      </div><!-- /#top -->
      <div id="left">
        <div class="media user-media bg-dark dker">
          <div class="user-media-toggleHover">
            <span class="fa fa-user"></span> 
          </div>
          <div class="user-wrapper bg-dark">
            <a class="user-link" href="">
              <img class="media-object img-thumbnail user-img" alt="User Picture" height = "100px" width= "100px" src="assets/img/Golf2.jpg">
             
            </a> 
            <div class="media-body">
              <h5 class="media-heading">User Name</h5>
              <ul class="list-unstyled user-info">
                <li> <a href="">Administrator</a>  </li>
                <li>Last Access :
                  <br>
                  <small>
                    <i class="fa fa-calendar"></i>&nbsp;16 July 16:32</small> 
                </li>
              </ul>
            </div>
          </div>
        </div>

        <!-- #menu -->
        <ul id="menu" class="bg-blue dker">
          <li class="nav-header">Menu</li>
          <li class="nav-divider"></li>
          <li class="">
            <a href="">
              <i class="fa fa-dashboard"></i><span class="link-title">&nbsp;Dashboard</span> 
            </a> 
          </li>
         
        
          <li class="">
            <a href="javascript:;">
              <i class="fa fa-pencil"></i>
              <span class="link-title">
            Operation
	  </span> 
              <span class="fa arrow"></span> 
            </a> 
            <ul>
              <li>
                <a href="form.php">
                  <i class="fa fa-angle-right"></i>&nbsp; Add New Member </a> 
              </li>

             
			  <li>
                <a href="Competition.php">
                  <i class="fa fa-angle-right"></i>&nbsp; Create a competition</a> 
              </li>
			 
            </ul>
          </li>
          <li class="active">
            <a href="memberList.php">
              <i class="fa fa-table"></i>
              <span class="link-title">Member List</span> 
            </a> 
          </li>
          <li>
            <a href="fileManager.php">
              <i class="fa fa-file"></i>
              <span class="link-title">
      Archive Files
          </span> </a> 
          </li>
         
          <li>
            <a href="viewCompetition.php">
              <i class="fa fa-table"></i><span class="link-title">
            Comeptition List
          </span> </a> 
          </li>
         

          <li class="nav-divider"></li>
          <li>
            <a href="logout.php">
              <i class="fa fa-sign-in"></i>
              <span class="link-title">
    Logout 
    </span> 
            </a> 
          </li>
 
        
        </ul><!-- /#menu -->
      </div><!-- /#left -->
      <?php
	echo"  <div id='content'>
       <div class='outer'>
       <div class='inner bg-light lter'>";

	include("db.php");
	$sql = "SELECT * FROM zh29_test2.Club_member Where Visibility = 1 ";
	$find_content = mysql_query($sql,$conn);
      ?>      
    <div class='row'>
              <div class='col-lg-12'>
                <div class='box'>
                  <header>
                    <div class='icons'>
                      <i class='fa fa-table'></i>
                    </div>
                    <h5>Members' Handicap Board</h5>
                  </header>
                  <div id='collapse4' class='body'>
                    <form action="" name= "frmUser" method = "post">
					<h2 align= "center">Members' Handicap Board</h2>
					<table id='dataTable' class='table table-bordered table-condensed table-hover table-striped'>
                      <thead>
                       
						<tr>
						
                          <th>Member ID</th>
						  <th>First Name</th>
                          <th>Last Name</th>
						  <th>Handicap</th>
                       
                          <th>Date of Birth</th>
                          
						  <th>Operation</th>
                        </tr>
				
                      </thead>
                      <tbody>
   <?php                  
while($record = mysql_fetch_array($find_content)){  ?>
	<tr>
	   
        <td><?php echo $record['member_id'] ?></td>
		<td><?php echo $record['first_name'] ?></td>
		<td ><?php echo $record['last_name']?></td>
		<td><?php echo $record['Handicap']?></td>
	
		<td><?php echo $record['BirthDate']?></td>
	

		
		<td align='center'>
			
		
		 
		 	<a href="dash.php?id=<?php echo $record['member_id'];?>"
    onclick="return confirm('To see all competitions this member participated?');">
    		<span class='view' title='Delete'style="color:#ff00bf"> View all records</span></a>
		 
</td>

	</tr>
	
	<?php
}?>

                      </tbody>
                    </table>
				
					<input  type="button" name="competitions" value="Go back"  onClick="memberList.php;" />
					
						<input type="button" name="enter" value="See bar graph"  onClick="Getbar();"/>
					</form>
                  </div>
                </div>
              </div>
            </div>
   
      </div><!-- /#content -->
   </div>
  <div id = "bargraph" style="display:none;">  
<svg id= "chart" width="1000px" bgcolor = "while" height="600px"></svg>
	
	</div>

    <footer class="Footer bg-dark dker">
      <p>2016 &copy; St Andrews Ladies' Putting Club</p>
    </footer><!-- /#footer -->

   

    <!--jQuery -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/datatables/1.10.4/js/jquery.dataTables.min.js"></script>
    <script src="//cdn.datatables.net/plug-ins/3cfcc339e89/integration/bootstrap/3/dataTables.bootstrap.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery.tablesorter/2.18.4/js/jquery.tablesorter.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jqueryui-touch-punch/0.2.3/jquery.ui.touch-punch.min.js"></script>

    <!--Bootstrap -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.min.js"></script>

    <!-- MetisMenu -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/metisMenu/1.1.3/metisMenu.min.js"></script>

    <!-- Screenfull -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/screenfull.js/2.0.0/screenfull.min.js"></script>

    <!-- Metis core scripts -->
    <script src="assets/js/core.min.js"></script>

    <!-- Metis demo scripts -->
    <script src="assets/js/app.js"></script>
    <script>
      $(function() {
        Metis.MetisTable();
        Metis.metisSortable();
      });
    </script>
    <script src="assets/js/style-switcher.min.js"></script>
  </body>
  </html>