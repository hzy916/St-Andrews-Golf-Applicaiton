<?php
session_start();
if( !$_SESSION['login_user']){
header("location:login.php;");
}

?>
<!doctype html>
<html class="no-js">
  <head>
    <meta charset="UTF-8">
    <title>Calendar</title>

    <!--IE Compatibility modes-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!--Mobile first-->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">

    <!-- Metis core stylesheet -->
    <link rel="stylesheet" href="assets/css/main.min.css">

    <!-- metisMenu stylesheet -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/metisMenu/1.1.3/metisMenu.min.css">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.5/fullcalendar.min.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

    <!--[if lt IE 9]>
      <script src="assets/lib/html5shiv/html5shiv.js"></script>
      <script src="assets/lib/respond/respond.min.js"></script>
      <![endif]-->

    <!--For Development Only. Not required -->
    <script>
      less = {
        env: "development",
        relativeUrls: false,
        rootpath: "../assets/"
      };
    </script>
    <link rel="stylesheet" href="assets/css/style-switcher.css">
    <link rel="stylesheet" href="assets/css/style-switcher.css">
    <link rel="stylesheet/less" type="text/css" href="assets/less/theme.less">
    <script src="//cdnjs.cloudflare.com/ajax/libs/less.js/2.2.0/less.min.js"></script>

    <!--Modernizr-->
    <script src="//cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
  </head>
  <body class="  ">
    <div class="bg-dark dk" id="wrap">
      <div id="top">

        <!-- .navbar -->
        <nav class="navbar navbar-inverse navbar-static-top">
          <div class="container-fluid">

            <!-- Brand and toggle get grouped for better mobile display -->
            <header class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                <span class="sr-only">Toggle navigation</span> 
                <span class="icon-bar"></span> 
                <span class="icon-bar"></span> 
                <span class="icon-bar"></span> 
              </button>
              
            </header>
            <div class="topnav">
              <div class="btn-group">
                <a data-placement="bottom" data-original-title="Fullscreen" data-toggle="tooltip" class="btn btn-default btn-sm" id="toggleFullScreen">
                  <i class="glyphicon glyphicon-fullscreen"></i>
                </a> 
              </div>
              <div class="btn-group">
                <a data-placement="bottom" data-original-title="E-mail" data-toggle="tooltip" class="btn btn-default btn-sm">
                  <i class="fa fa-envelope"></i>
                  <span class="label label-warning">5</span> 
                </a> 
                <a data-placement="bottom" data-original-title="Messages" href="#" data-toggle="tooltip" class="btn btn-default btn-sm">
                  <i class="fa fa-comments"></i>
                  <span class="label label-danger">4</span> 
                </a> 
                <a data-toggle="modal" data-original-title="Help" data-placement="bottom" class="btn btn-default btn-sm" href="#helpModal">
                  <i class="fa fa-question"></i>
                </a> 
              </div>
              <div class="btn-group">
                <a href="login.html" data-toggle="tooltip" data-original-title="Logout" data-placement="bottom" class="btn btn-metis-1 btn-sm">
                  <i class="fa fa-power-off"></i>
                </a> 
              </div>
              <div class="btn-group">
                <a data-placement="bottom" data-original-title="Show / Hide Left" data-toggle="tooltip" class="btn btn-primary btn-sm toggle-left" id="menu-toggle">
                  <i class="fa fa-bars"></i>
                </a> 
                <a data-placement="bottom" data-original-title="Show / Hide Right" data-toggle="tooltip" class="btn btn-default btn-sm toggle-right"> <span class="glyphicon glyphicon-comment"></span>  </a> 
              </div>
            </div>
            <div class="collapse navbar-collapse navbar-ex1-collapse">

              <!-- .nav -->
              <ul class="nav navbar-nav">
                <li> <a href="dashboard.html">Dashboard</a>  </li>
                <li> <a href="table.html">Tables</a>  </li>
                <li> <a href="file.html">File Manager</a>  </li>
                <li class='dropdown '>
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    Form Elements
                    <b class="caret"></b>
                  </a> 
                  <ul class="dropdown-menu">
                    <li> <a href="form-general.html">General</a>  </li>
                    <li> <a href="form-validation.html">Validation</a>  </li>
                    <li> <a href="form-wysiwyg.html">WYSIWYG</a>  </li>
                    <li> <a href="form-wizard.html">Wizard &amp; File Upload</a>  </li>
                  </ul>
                </li>
              </ul><!-- /.nav -->
            </div>
          </div><!-- /.container-fluid -->
        </nav><!-- /.navbar -->
        <header class="head">
          <div class="search-bar">
           
          </div><!-- /.search-bar -->
          <div class="main-bar">
            <h3>
              <i class="fa fa-calendar"></i>&nbsp; Calendar</h3>
          </div><!-- /.main-bar -->
        </header><!-- /.head -->
      </div><!-- /#top -->
      <div id="left">
        <div class="media user-media bg-dark dker">
          <div class="user-media-toggleHover">
            <span class="fa fa-user"></span> 
          </div>
          <div class="user-wrapper bg-dark">
            <a class="user-link" href="">
              <img class="media-object img-thumbnail user-img" alt="User Picture" src="assets/img/user.gif">
              <span class="label label-danger user-label">16</span> 
            </a> 
            <div class="media-body">
              <h5 class="media-heading">Archie</h5>
              <ul class="list-unstyled user-info">
                <li> <a href="">Administrator</a>  </li>
                <li>Last Access :
                  <br>
                  <small>
                    <i class="fa fa-calendar"></i>&nbsp;16 Mar 16:32</small> 
                </li>
              </ul>
            </div>
          </div>
        </div>

        <!-- #menu -->
        <ul id="menu" class="bg-blue dker">
          <li class="nav-header">Menu</li>
          <li class="nav-divider"></li>
          <li class="">
            <a href="dashboard.php">
              <i class="fa fa-dashboard"></i><span class="link-title">&nbsp;Dashboard</span> 
            </a> 
          </li>
       
      
          <li class="">
            <a href="javascript:;">
              <i class="fa fa-pencil"></i>
              <span class="link-title">
            Forms
	  </span> 
              <span class="fa arrow"></span> 
            </a> 
            <ul>
              <li>
                <a href="form-general.html">
                  <i class="fa fa-angle-right"></i>&nbsp; Form General </a> 
              </li>
              <li>
                <a href="form-validation.html">
                  <i class="fa fa-angle-right"></i>&nbsp; Form Validation </a> 
              </li>
            
            </ul>
          </li>
          <li>
            <a href="Test1.2.php">
              <i class="fa fa-table"></i>
              <span class="link-title">Tables</span> 
            </a> 
          </li>
          <li>
            <a href="fileManager.php">
              <i class="fa fa-file"></i>
              <span class="link-title">
      File Manager
          </span> </a> 
          </li>
         
          <li>
            <a href="">
              <i class="fa fa-map-marker"></i><span class="link-title">
            Maps
          </span> </a> 
          </li>
          <li>
            <a href="">
              <i class="fa fa fa-bar-chart-o"></i>
              <span class="link-title">
            Charts
          </span> </a> 
          </li>
          <li class="active">
            <a href="calendar.html">
              <i class="fa fa-calendar"></i>
              <span class="link-title">
            Calendar
          </span> </a> 
          </li>

          <li class="nav-divider"></li>
          <li>
            <a href="login.php">
              <i class="fa fa-sign-in"></i>
              <span class="link-title">
    Login Page
    </span> 
            </a> 
          </li>
          <li>
           
      </div><!-- /#left -->
      <div id="content">
        <div class="outer">
          <div class="inner bg-light lter">
            <div class="box">
              <header>
                <h5>Calendar</h5>
              </header>
              <div class="body">
                <div class="row">
                  <div class="col-lg-3">
                    <div class="well well-sm">
                      <div id="add-event-form">
                        <fieldset>
                          <legend>Add Custom Event</legend>
                          <span class="help-block">Event Title</span> 
                          <input id="title" name="title" type="text" placeholder="event title" class="form-control input-small">
                          <div class="radio">
                            <label>
                              <input type="radio" name="priority" value="label label-default" checked>
                              <span class="label label-default">default</span> 
                            </label>
                          </div>
                          <div class="radio">
                            <label>
                              <input type="radio" name="priority" value="label label-primary">
                              <span class="label label-primary">primary</span> 
                            </label>
                          </div>
                          <div class="radio">
                            <label>
                              <input type="radio" name="priority" value="label label-warning">
                              <span class="label label-warning">warning</span> 
                            </label>
                          </div>
                          <div class="radio">
                            <label>
                              <input type="radio" name="priority" value="label label-success">
                              <span class="label label-success">success</span> 
                            </label>
                          </div>
                          <div class="radio">
                            <label>
                              <input type="radio" name="priority" value="label label-info">
                              <span class="label label-info">info</span> 
                            </label>
                          </div>
                          <div class="radio">
                            <label>
                              <input type="radio" name="priority" value="label label-danger">
                              <span class="label label-danger">danger</span> 
                            </label>
                          </div>
                          <br>
                          <button id="add-event" type="button" class="btn btn-sm btn-default">Add Event</button>
                        </fieldset>
                      </div>
                    </div>
                    <div class="well well-sm">
                      <h4>Draggable Events</h4>
                      <ul id='external-events' class="list-unstyled">
                        <li class="external-event"><span class="label label-default">Golf Course 1</span> </li>
                        <li class="external-event"><span class="label label-primary">Golf Course 2</span> </li>
                        <li class="external-event"><span class="label label-danger">My Event 3</span> </li>
                        <li class="external-event"><span class="label label-success">My Event 4</span> </li>
                        <li class="external-event"><span class="label label-warning">My Event 5</span> </li>
                        <li class="external-event"><span class="label label-info">My Event 6</span> </li>
                      </ul>
                      <div class="checkbox anim-checkbox h4">
                        <input type="checkbox" id="drop-remove" class="danger">
                        <label for="drop-remove">remove after drop</label>
                      </div>
                    </div>
                  </div>
                  <div id="calendar" class="col-lg-9"></div>
                </div>
              </div>
            </div>
          </div><!-- /.inner -->
        </div><!-- /.outer -->
      </div><!-- /#content -->
     
    </div><!-- /#wrap -->
    <footer class="Footer bg-dark dker">
      <p>2016 &copy; St Andrews Ladies' Putting Club</p>
    </footer><!-- /#footer -->

   

    <!--jQuery -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.5/fullcalendar.min.js"></script>

    <!--Bootstrap -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.min.js"></script>

    <!-- MetisMenu -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/metisMenu/1.1.3/metisMenu.min.js"></script>

    <!-- Screenfull -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/screenfull.js/2.0.0/screenfull.min.js"></script>

    <!-- Metis core scripts -->
    <script src="assets/js/core.min.js"></script>

    <!-- Metis demo scripts -->
    <script src="assets/js/app.js"></script>
    <script>
      $(function() {
        Metis.MetisCalendar();
      });
    </script>
    <script src="assets/js/style-switcher.min.js"></script>
  </body>