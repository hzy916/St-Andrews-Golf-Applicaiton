<!DOCTYPE html>
<html>
<head>
<title>line&bar</title>


</head>
<meta charset="utf-8">
<style>

body { font: 12px Arial;}

path { 
    stroke: steelblue;
    stroke-width: 2;
    fill: none;
}

.axis path,
.axis line {
    fill: none;
    stroke: black;
    stroke-width: 3;
    shape-rendering: crispEdges;
}

div.tooltip {	
    position: absolute;			
    text-align: center;			
    width: 140px;					
    height: 60px;					
    padding: 2px;				
    font: 16px sans-serif;		
    background: lightsteelblue;	
    border: 0px;		
    border-radius: 8px;			
    pointer-events: none;			
}
#Selectlabel {
font-size: 20px;
font-family: Serif;
display: inline-block;
}

</style>


<body>
<script type="text/javascript" src="d3.v3.js"></script>
<script src="d3.v3.min.js"></script>
<script src="getdata.js"></script>

<div id = "buttons">
<h1>Handicap Graph</h1>

	<button onclick="UpdateHandicap()">Handicap</button>
	
</div>
<svg id= "chart" width="1000px" height="600px"></svg>
<script>
function UpdateHandicap() {
// Get the data

d3.json("MembersData.php", function(error, data) {

var margin = {top: 30, right: 40, bottom: 100, left: 80},
    ww = document.getElementById("chart").clientWidth,         //to make the svg part responsive to different devices.
	width = ww - margin.left - margin.right,
    height = 600 - margin.top - margin.bottom;

	//var parseDate = d3.time.format("%Y-%m-%d").parse;
    
	data.forEach(function(d) {
        d.member_id = +d.member_id;
        d.Handicap = +d.Handicap;
		
    });
d3.selectAll("svg > *").remove();

//var formatTime = d3.time.format("%e %B");
//var formatTime = d3.time.format("%Y-%m-%d");
var x = d3.time.scale()
		  .range([0, width])
		   .domain(d3.extent(data, function(d) { return d.member_id; }));

var y = d3.scale.linear()
                .range([height, 0])
				.domain(d3.extent(data,function(d) { return d.Handicap;}));


   var xAxis = d3.svg.axis().scale(x)
    .orient("bottom")
	
  // .tickFormat(d3.time.format("%Y-%m-%d"));
	
var yAxis = d3.svg.axis().scale(y)
    .orient("left");
	

	//  Define the div for the bar chart tooltip 
	var divbar = d3.select("body").append("div")	
    .attr("class", "tooltip")				
    .style("opacity", 0);
	
var svg = d3.select("svg")
    .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
    .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    svg.append("g")         // Add the X Axis
        .attr("class", "x axis")
        .attr("transform", "translate(0," + height + ")")
        .call(xAxis)
		
		.selectAll("text")  
            .style("text-anchor", "end") 
            .attr("dx", "-.8em")
            .attr("dy", ".15em")
            .attr("transform", "rotate(-40)" );          //rotate the text label for x-axis
 
    svg.append("g")         // Add the Y Axis
        .attr("class", "y axis")
		.attr("id", "leftYAxis")
        .call(yAxis);

   // add the bar chart
   
    svg.selectAll('.chart')
	.data(data)
    .enter().append('rect')
    .attr('class', 'bar')
	.attr("id", "barchart")
    .attr('x', function(d) { return x(d.member_id); })
    .attr('y', function(d) { return height - margin.top - margin.bottom - (height - margin.top - margin.bottom -y(d.Handicap))})
    .attr('width', 10)
    .attr('height', function(d) { return height - y(d.Handicap) })
     //add mouse events
	.attr('fill', 'grey')
    .on('mouseover',function(d){
      d3.select(this)
        .attr('fill','orange');
	  divbar.transition()		
                .duration(200)		
                .style("opacity", .9);		
		divbar.html( "Member ID:"+d.member_id + "<br/>"+ "Handicap:" + d.Handicap+"<br/>" 
		+ "First Name:" + d.first_name+"<br/>"+  "Last Name:" + d.last_name)	
			.style("left", (d3.event.pageX) + "px")		
			.style("top", (d3.event.pageY - 28) + "px");	
    })
    .on('mouseout',function(d){
      d3.select(this)
        .attr('fill','grey');
	   divbar.transition()		
                .duration(500)		
                .style("opacity", 0);	
    });

    // Add the bar chart title
		svg.append("text")
			.attr("x", 0)             
			// .attr("x", width)
             .attr("y", margin.bottom + height)  
			.attr("class", "legend")
			.style("fill", "blue")         
			.on("click", function(){
				// Determine if current line is visible
				var activebar   = barchart.active ? false : true,
				  newOpacity = activebar ? 0 : 1;
				// Hide or show the elements
				d3.selectAll("#barchart").style("opacity", newOpacity);
				d3.select("#rightYAxis").style("opacity", newOpacity);
				// Update whether or not the elements are active
				barchart.active = activebar;
			})
			
	// now add titles to the axes
         svg.append("text")
    .attr("class", "x label")
   .attr("text-anchor", "end")
	//	.style("text-anchor","middle")
    .attr("x", width/2)
   .attr("y", margin.bottom + height)
   .text("Player's ID");
  // .style("font-size", 16px);
	    
		svg.append("text")
    .attr("class", "y label")
    .attr("text-anchor", "end")
	.attr("x", -90)
    .attr("y", -60)
//	.style("text-anchor","middle")
    .attr("dy", "1em")
    .attr("transform", "rotate(-90)")
    .text("Handicap");

	 });	
	 }
	 
	 </script>
	  </body>

</html>	