<?php 
//Find errors of blank page;
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 'On');

ob_start();
include('db.php');
if(isset($_GET['id']))
{
  $id=$_GET['id'];

  if(isset($_POST['update']))
  {
  $efirstname=$_POST['efirstname'];
  $elastname=$_POST['elastname'];
  $eusermail=$_POST['eusermail'];
  $ebirthdate=$_POST['ebirthdate'];
  $eusermobile=$_POST['eusermobile'];
  $updated= mysql_query("UPDATE Club_member SET first_name='$efirstname', last_name='$elastname', email='$eusermail',phone_number='$eusermobile', BirthDate = '$ebirthdate' WHERE member_id='$id'")or die();
  
  if($updated)
  {
    echo'<script language ="javascript">';
	echo'alert("Successfully Updated!");location.href="memberList.php"';
	echo'</script>';
  }
}
}
ob_end_flush();
?>
<!doctype html>
<html class="no-js">
  <head>
    <meta charset="UTF-8">
    <title>Add new member</title>

    <!--IE Compatibility modes-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!--Mobile first-->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">

    <!-- Metis core stylesheet -->
    <link rel="stylesheet" href="assets/css/main.min.css">

    <!-- metisMenu stylesheet -->
 
    <link rel="stylesheet" href="assets/lib/jquery-inputlimiter/jquery.inputlimiter.1.0.css">
    <link rel="stylesheet" href="assets/lib/bootstrap-daterangepicker/daterangepicker-bs3.css">
   <!-- <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/Uniform.js/2.1.2/themes/default/css/uniform.default.min.css">-->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/chosen/1.1.0/chosen.min.css">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jquery-tagsinput/1.3.3/jquery.tagsinput.css">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jasny-bootstrap/3.1.3/css/jasny-bootstrap.min.css">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-switch/3.3.6/css/bootstrap3/bootstrap-switch.min.css">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.1/css/datepicker3.min.css">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-colorpicker/2.0.1/css/bootstrap-colorpicker.min.css">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/3.1.3/css/bootstrap-datetimepicker.min.css">

   

    <!--For Development Only. Not required -->
    <script>
      less = {
        env: "development",
        relativeUrls: false,
        rootpath: "../assets/"
      };
    </script>
    <link rel="stylesheet" href="assets/css/style-switcher.css">
    <link rel="stylesheet/less" type="text/css" href="assets/less/theme.less">
    <script src="//cdnjs.cloudflare.com/ajax/libs/less.js/2.2.0/less.min.js"></script>

    <!--Modernizr-->
    <script src="//cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
  </head>
  <body class="  ">
    <div class="bg-dark dk" id="wrap">
      <div id="top">

        <!-- .navbar -->
        <nav class="navbar navbar-inverse navbar-static-top">
          <div class="container-fluid">

            <!-- Brand and toggle get grouped for better mobile display -->
            <header class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                <span class="sr-only">Toggle navigation</span> 
                <span class="icon-bar"></span> 
                <span class="icon-bar"></span> 
                <span class="icon-bar"></span> 
              </button>
              
            </header>
            <div class="topnav">
              <div class="btn-group">
                <a data-placement="bottom" data-original-title="Fullscreen" data-toggle="tooltip" class="btn btn-default btn-sm" id="toggleFullScreen">
                  <i class="glyphicon glyphicon-fullscreen"></i>
                </a> 
              </div>
              <div class="btn-group">
              
                <a data-toggle="modal" data-original-title="Help" data-placement="bottom" class="btn btn-default btn-sm" href="#helpModal">
                  <i class="fa fa-question"></i>
                </a> 
              </div>
              <div class="btn-group">
                <a href="login.html" data-toggle="tooltip" data-original-title="Logout" data-placement="bottom" class="btn btn-metis-1 btn-sm">
                  <i class="fa fa-power-off"></i>
                </a> 
              </div>
              <div class="btn-group">
                <a data-placement="bottom" data-original-title="Show / Hide Left" data-toggle="tooltip" class="btn btn-primary btn-sm toggle-left" id="menu-toggle">
                  <i class="fa fa-bars"></i>
                </a> 
                <a data-placement="bottom" data-original-title="Show / Hide Right" data-toggle="tooltip" class="btn btn-default btn-sm toggle-right"> <span class="glyphicon glyphicon-comment"></span>  </a> 
              </div>
            </div>
            <div class="collapse navbar-collapse navbar-ex1-collapse">

              <!-- .nav -->
              <ul class="nav navbar-nav">
               
                <li> <a href="table.html">Log in</a>  </li>
				 
				 <li class='dropdown active'>
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    Table of Member
                    <b class="caret"></b>
                  </a> 
                  <ul class="dropdown-menu">
                    <li> <a href="memberList.php">View member info</a>  </li>
                    <li> <a href="form.php">Add a member</a>  </li>
                    <li> <a href="search.php">Search</a></li>
                    <li> <a href="form-wizard.html"> </a>  </li>
                  </ul>
                </li>
                <li> <a href="file.html">File Manager</a>  </li>
				<li> <a href="dashboard.html">Report Dashboard</a>  </li>
				
               
              </ul><!-- /.nav -->
            </div>
          </div><!-- /.container-fluid -->
        </nav><!-- /.navbar -->
        <header class="head">
          <div class="search-bar">
            
			
			
          </div><!-- /.search-bar -->
          <div class="main-bar">
            <h3>
              <i class="fa fa-pencil"></i>&nbsp; Update Member Form</h3>
          </div><!-- /.main-bar -->
        </header><!-- /.head -->
      </div><!-- /#top -->
      <div id="left">
        <div class="media user-media bg-dark dker">
          <div class="user-media-toggleHover">
            <span class="fa fa-user"></span> 
          </div>
          <div class="user-wrapper bg-dark">
            <a class="user-link" href="">
              <img class="media-object img-thumbnail user-img" alt="User Picture" src="assets/img/user.gif">
              <span class="label label-danger user-label">16</span> 
            </a> 
            <div class="media-body">
              <h5 class="media-heading">Archie</h5>
              <ul class="list-unstyled user-info">
                <li> <a href="">Administrator</a>  </li>
                <li>Last Access :
                  <br>
                  <small>
                    <i class="fa fa-calendar"></i>&nbsp;16 Mar 16:32</small> 
                </li>
              </ul>
            </div>
          </div>
        </div>

        <!-- #menu -->
        <ul id="menu" class="bg-blue dker">
          <li class="nav-header">Menu</li>
          <li class="nav-divider"></li>
          <li class="">
            <a href="dashboard.php">
              <i class="fa fa-dashboard"></i><span class="link-title">&nbsp;Report Dashboard</span> 
            </a> 
          </li>
         
          </li>
          <li class="active">
            <a href="javascript:;">
              <i class="fa fa-pencil"></i>
              <span class="link-title">
            Forms
	  </span> 
              <span class="fa arrow"></span> 
            </a> 
          
              <li>
                <a href="form.php">
                  <i class="fa fa-angle-right"></i>&nbsp; Adding Members </a> 
              </li>
             
              <li>
                <a href="Competition.php">
                  <i class="fa fa-angle-right"></i>&nbsp; Create Compeitions </a> 
              </li>
             
       
          </li>
          <li>
            <a href="memberList.php">
              <i class="fa fa-table"></i>
              <span class="link-title">Tables</span> 
            </a> 
          </li>
          <li>
            <a href="fileManager.php">
              <i class="fa fa-file"></i>
              <span class="link-title">
      File Manager
          </span> </a> 
          </li>
          
          <li>
            <a href="">
              <i class="fa fa-map-marker"></i><span class="link-title">
            Maps
          </span> </a> 
          </li>
          <li>
            <a href="">
              <i class="fa fa fa-bar-chart-o"></i>
              <span class="link-title">
            Charts
          </span> </a> 
          </li>
          <li>
            <a href="">
              <i class="fa fa-calendar"></i>
              <span class="link-title">
            Calendar
          </span> </a> 
          </li>

          <li class="nav-divider"></li>
          <li>
            <a href="login.php">
              <i class="fa fa-sign-in"></i>
              <span class="link-title">
    Login Page
    </span> 
            </a> 
          </li>
         
        </ul><!-- /#menu -->
      </div><!-- /#left -->
      <div id="content">
        <div class="outer">
          <div class="inner bg-light lter">

            <!--BEGIN INPUT TEXT FIELDS-->
            <div class="row">
              <div class="col-lg-6">
                <div class="box dark">
                  <header>
                    <div class="icons">
                      <i class="fa fa-edit"></i>
                    </div>
                    <h5>Edit Area</h5>

                    <!-- .toolbar -->
                    <div class="toolbar">
                      <nav style="padding: 8px;">
                        <a href="javascript:;" class="btn btn-default btn-xs collapse-box">
                          <i class="fa fa-minus"></i>
                        </a> 
                        <a href="javascript:;" class="btn btn-default btn-xs full-box">
                          <i class="fa fa-expand"></i>
                        </a> 
                        <a href="javascript:;" class="btn btn-danger btn-xs close-box">
                          <i class="fa fa-times"></i>
                        </a> 
                      </nav>
                    </div><!-- /.toolbar -->
                  </header>

<?php 
  if(isset($_GET['id']))
  {
  $id=$_GET['id'];
  $getselect=mysql_query("SELECT * FROM Club_member WHERE member_id='$id'");
  while($profile=mysql_fetch_array($getselect))
  {
    $id=$profile['member_id'];
	$firstname=$profile['first_name'];
    $usermail=$profile['email'];
	$birthdate=$profile['BirthDate'];
    $lastname=$profile['last_name'];
	$phonenumber=$profile['phone_number'];
?>
 <div id="div-1" class="body">
  <form class="form-horizontal" action="" method="post">
<center><h1>Edit Member Information</h1></center>
  
  <div class="form-group">
    <label for="text1" class="control-label col-lg-4">First Name</label>
	
	<div class="col-lg-8">
   
      <input type="text" name="efirstname" required  placeholder="Enter First Name" 
		value="<?php echo $firstname; ?>" id="inputid" class="form-control" />
    </div>
	 </div>
	
	<div class="form-group">
      <label for="text1" class="control-label col-lg-4">Last Name</label>
	  <div class="col-lg-8">
      <input type="text" name="elastname" required placeholder="Enter Last Name" 
      value="<?php echo $lastname; ?>" id="inputid" />
    </div>
	 </div>
	
    <div class="form-group">
      <label  for="email"  class="control-label col-lg-4"> Email: </label>
      <div class="col-lg-8">
	  <input type="email" name="eusermail" required placeholder="Enter Email" 
      value="<?php echo $usermail; ?>" id="inputid" />
     </div>
	</div>
	
	<div class="form-group">
      <label for="mobile" class="control-label col-lg-4"> Phone Number : </label>
      <div class="col-lg-8">
	  <input type="text" name="eusermobile" required placeholder="Enter mobile number" 
      value="<?php echo $phonenumber; ?>" id="inputid" />
    </div>
	</div>
	
	<div class="form-group">
      <label for="birthdate" class="control-label col-lg-4"> Date of Birth : </label>
      <div class="col-lg-8">
	  <input type="date" name="ebirthdate" required placeholder="Enter Date of Birth" 
      value="<?php echo $birthdate; ?>" id="inputid" />
     </div>
     </div>
	
	
      
   <div class="form-group" >
      <div align ="center" class="col-lg-8"> 
	 <input type="button" name="back" value="back" id="inputid" style= "position:relative;" onclick ="window.location.href='memberList.php'" />
	  <input type="submit" name="update" value="Update" id="inputid" />
	</div>
	
  </form>
</div>
<?php  }}?>
</div>
              </div>
			  </div>
<br>
			</div>
			</div>
			</div>
    <footer class="Footer bg-dark dker">
      <p>2016 &copy; St Andrews Ladies' Putting Club</p>
    </footer><!-- /#footer -->

  

    <!--jQuery -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/Uniform.js/2.1.2/jquery.uniform.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/chosen/1.1.0/chosen.jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-tagsinput/1.3.3/jquery.tagsinput.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/autosize.js/1.18.17/jquery.autosize.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jasny-bootstrap/3.1.3/js/jasny-bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-switch/3.3.6/js/bootstrap-switch.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.1/js/bootstrap-datepicker.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-colorpicker/2.0.1/js/bootstrap-colorpicker.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/3.1.3/js/bootstrap-datetimepicker.min.js"></script>

    <!--Bootstrap -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.min.js"></script>

    <!-- MetisMenu -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/metisMenu/1.1.3/metisMenu.min.js"></script>

    <!-- Screenfull -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/screenfull.js/2.0.0/screenfull.min.js"></script>
    <script src="assets/lib/jquery-inputlimiter/jquery.inputlimiter.1.3.1.min.js"></script>
    <script src="assets/lib/jQuery.validVal/js/jquery.validVal.min.js"></script>
    <script src="assets/lib/bootstrap-daterangepicker/daterangepicker.js"></script>

    <!-- Metis core scripts -->
    <script src="assets/js/core.min.js"></script>

    <!-- Metis demo scripts -->
    <script src="assets/js/app.js"></script>
    <script>
      $(function() {
        Metis.formGeneral();
      });
    </script>
    <script src="assets/js/style-switcher.min.js"></script>
  </body>
  </html>