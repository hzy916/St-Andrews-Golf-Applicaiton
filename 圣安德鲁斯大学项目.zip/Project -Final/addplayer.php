<?php

 include("db.php");
 $comp = $_POST['comp'];

//extract the member ID from the form submit value
 $users_string = $_POST['users'];
// var_dump($users_string);
 $users = explode("=> ", $users_string[0]);
// var_dump($users);
 $users_arr = array();
 for ($i = 1; $i<count($users); $i++) {
	 $id = intval($users[$i]);
	 array_push($users_arr, $id);
 }

  $db = mysqli_connect("zh29.host.cs.st-andrews.ac.uk:3306","zh29","V.Qs8Q6z2PYwCs","zh29_test2");

if ($users_arr && $comp)
{
	foreach ($users_arr as $c){
		$sql1 = "INSERT INTO Score(memberID,CompetitionID) VALUES 
		(" . $c . "," . $comp[0] . ")";
		
		$result = mysqli_query($db,$sql1);
	}
  
	
}
    
if(!$result)
{
    die('Duplicate error in adding players! ' . mysql_error());
}else{
	echo'<script language ="javascript">';
   echo'alert("Add to competition successfully!");';
 
  echo'location.href="viewCompetition.php";';
     echo'</script>';
	
}

?>