<?php
  ob_start();
  include("db.php");
  if(isset($_GET['id'])!="")
  {
  $undo=$_GET['id'];

  $undo = mysql_query("UPDATE Club_member set Visibility = 1 WHERE member_id = '$undo'");
  if($undo)
  {
	echo'<script language ="javascript">';
	echo'alert("Successfully Recovered!"); location.href="fileManager.php"';
	echo'</script>';
	  //header("Location:index.php");
  }
  else
  {
	  echo mysql_error();
  }
  }
  ob_end_flush();
 //
?>