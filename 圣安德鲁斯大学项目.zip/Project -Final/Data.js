function Getbar() {
// Get the data

   document.getElementById('bargraph').style.display = "block";


d3.json("MembersData.php", function(error, data) {

var margin = {top: 30, right: 40, bottom: 100, left: 80},
    ww = document.getElementById("chart").clientWidth,         //to make the svg part responsive to different devices.
	width = ww - margin.left - margin.right,
    height = 600 - margin.top - margin.bottom;

	//var parseDate = d3.time.format("%Y-%m-%d").parse;
  
d3.selectAll("svg > *").remove();


var x = d3.scale.linear()
		  .range([0, width])
		 //  .domain(d3.extent(data, function(d) { return d.member_id; }));
            .domain([0,25]);
var y = d3.scale.linear()
                .range([height, 0])
			//	.domain(d3.extent(data,function(d) { return d.Handicap;}));
				.domain([-10,10]);

   var xAxis = d3.svg.axis().scale(x)
    .orient("bottom")
	
 
	
var yAxis = d3.svg.axis().scale(y)
    .orient("left");
	

	//  Define the div for the bar chart tooltip 
	var divbar = d3.select("body").append("div")	
    .attr("class", "tooltip")				
    .style("opacity", 0);
	
var svg = d3.select("svg")
    .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
    .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    svg.append("g")         // Add the X Axis
        .attr("class", "x axis")
        .attr("transform", "translate(0," + height + ")")
        .call(xAxis)
		
		.selectAll("text")  
            .style("text-anchor", "end") 
            .attr("dx", "-.8em")
            .attr("dy", ".15em")
            .attr("transform", "rotate(-40)" );          //rotate the text label for x-axis
 
    svg.append("g")         // Add the Y Axis
        .attr("class", "y axis")
		.attr("id", "leftYAxis")
        .call(yAxis);

   // add the bar chart
   
    svg.selectAll('.chart')
	.data(data)
    .enter().append('rect')
    .attr('class', 'bar')
	.attr("id", "barchart")
    .attr('x', function(d) { return x(d.member_id); })
    .attr('y', function(d) { return height - margin.top - margin.bottom - (height - margin.top - margin.bottom -y(d.Handicap))})
    .attr('width', 10)
    .attr('height', function(d) { return height - y(d.Handicap) })
     //add mouse events
	.attr('fill', '#ffff66')
    .on('mouseover',function(d){
      d3.select(this)
        .attr('fill','#0066ff');
	  divbar.transition()		
                .duration(200)		
                .style("opacity", .9);		
		divbar.html( "Member ID:"+d.member_id + "<br/>"+ "Handicap:" + d.Handicap+"<br/>" 
		+ "First Name:" + d.first_name+"<br/>"+  "Last Name:" + d.last_name)	
			.style("left", (d3.event.pageX) + "px")		
			.style("top", (d3.event.pageY - 28) + "px");	
    })
    .on('mouseout',function(d){
      d3.select(this)
        .attr('fill','#ffff66');
	   divbar.transition()		
                .duration(500)		
                .style("opacity", 0);	
    });

    // Add the bar chart title
		svg.append("text")
			.attr("x", 0)             
			// .attr("x", width)
             .attr("y", margin.bottom + height)  
			.attr("class", "legend")
			.style("fill", "blue")         
			.on("click", function(){
				// Determine if current line is visible
				var activebar   = barchart.active ? false : true,
				  newOpacity = activebar ? 0 : 1;
				// Hide or show the elements
				d3.selectAll("#barchart").style("opacity", newOpacity);
				d3.select("#rightYAxis").style("opacity", newOpacity);
				// Update whether or not the elements are active
				barchart.active = activebar;
			})
			
	// now add titles to the axes
         svg.append("text")
    .attr("class", "x label")
   .attr("text-anchor", "end")
	//	.style("text-anchor","middle")
    .attr("x", width/2)
   .attr("y", margin.bottom )
   .text("Player's ID");
 
 
	    
		svg.append("text")
    .attr("class", "y label")
    .attr("text-anchor", "end")
	.attr("x", -90)
    .attr("y", -60)

    .attr("dy", "1em")
    .attr("transform", "rotate(-90)")
    .text("Handicap");

	 });	
	 }