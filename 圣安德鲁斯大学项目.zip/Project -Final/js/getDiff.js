function getDiff() {
var Diff = $('table#dataTable').find('tbody').find('tr');
//console.log(Diff);
var empty = [];
for (var i = 0; i < Diff.length; i++) {

var score = $(Diff[i]).find('td:eq(8)').text();
//console.log(parseInt(score));
empty.push(parseInt(score));

}
console.log(empty);
return empty;
}


function findNaN(array){	
  for(i = 0; i<array.length; i++){
	 var item =  array[i];
     if(isNaN(item)){
		   return true;
     }
  }
  return false;
}

 

//calculate scratch

function getAvg(arr){
var total = 0;
for(var i = 0; i < arr.length; i++) {
    total += arr[i];
}
var avgDiff =Math.round(total / arr.length);

console.log(avgDiff);
return avgDiff;
document.getElementById("p3").innerHTML = "<b>Average Differential:</b>"+avgDiff;

}



//UpdateHandicap(handica,mID,getAvg(empty));

function UpdateHandicap(){
//to get member current handicap
var handic = $('table#dataTable').find('tbody').find('tr');
var handica = $(handic[0]).find('td:eq(3)').text();
var handicap = parseInt(handica);
console.log(handicap);

//if NaN IS EDITABLE





//to get member id
var mid = $('table#dataTable').find('tbody').find('tr');
var mID = $(handic[0]).find('td:eq(0)').text();
console.log(mID);

var diff = getDiff();

if (findNaN(diff)==false){
 var diffAvg = getAvg(diff);
}  
	
	if(handicap > diffAvg){
		handicap = handicap-1;
	}else if (handicap<diffAvg){
		handicap = handicap+1;
	}
	 console.log(handicap);
	 
	  $.ajax({
	type: "POST",
                    url: 'updateHandicap.php',
                    data: {handicap: handicap,memberid:mID},
                    success: function(data)
                    {
                       alert("success!");
                    }
	
})
	  

}