<?php

 include("db.php");
   session_start();
   if(isset($_POST['login'])) {
      // username and password sent from form 
         
		$username = $_POST['lname'];
		$mypassword = $_POST['lpassword'];
    
	//echo $username;
		$username = strip_tags(trim($username));
		$mypassword = strip_tags(trim($mypassword));

		//$password = hash('sha256', $mypassword); // password hashing using SHA256
		$sql= "SELECT * FROM Admin WHERE adname='$username' AND adpassword = '$mypassword'";  
    // echo $sql;
	  $res=mysql_query($sql); if (!$res) {   die('Invalid query: ' . mysql_error());}
	  
	//  echo $res;
      $result = mysql_num_rows($res);

  if($result>0) {
	 $_SESSION['login_user']= true;
   echo'<script language ="javascript">';
   echo'alert(" Login Successfully!");';
   echo'</script>';
   header("Location:login_success.php");
 //  exit();
  } else {
	   echo'<script language ="javascript">';
   echo'alert("Wrong username or password");';
 
   echo'location.href="login.php";';
     echo'</script>';
  }// 
 }

?>

