<!DOCTYPE html>
<html>
<head>
<title>line&bar</title>


</head>
<meta charset="utf-8">
<style>

body { font: 12px Arial;}

path { 
    stroke: steelblue;
    stroke-width: 2;
    fill: none;
}

.axis path,
.axis line {
    fill: none;
    stroke: black;
    stroke-width: 3;
    shape-rendering: crispEdges;
}

div.tooltip {	
    position: absolute;			
    text-align: center;			
    width: 140px;					
    height: 70px;					
    padding: 2px;				
    font: 16px sans-serif;		
    background: lightsteelblue;	
    border: 0px;		
    border-radius: 8px;			
    pointer-events: none;			
}
#Selectlabel {
font-size: 20px;
font-family: Serif;
display: inline-block;
}

</style>


<body>
<script type="text/javascript" src="js/d3.v3.js"></script>
<script src="js/d3.v3.min.js"></script>

<div id = "buttons">
<h1>Handicap Graph</h1>

	<button onclick="wind()">Handicap</button>
	
</div>
<svg id= "chart" width="1000px" height="600px"></svg>



<script>
function wind () {

d3.json("Getdata.php", function(error, data) {
   console.log(data);
var margin = {top: 30, right: 40, bottom: 100, left: 80},
    ww = document.getElementById("chart").clientWidth,            //to make the svg part responsive to different devices.
	width = ww - margin.left - margin.right,
    height = 600 - margin.top - margin.bottom;

	var parseDate = d3.time.format("%Y-%m-%d").parse;
    
	data.forEach(function(d) {
        d.BirthDate= parseDate(d.BirthDate);
        d.Handicap = +d.Handicap;
		
    });
d3.selectAll("svg > *").remove();

//var formatTime = d3.time.format("%e %B");
var formatTime = d3.time.format("%Y-%m-%d");
var x = d3.time.scale()
		  .range([0, width])
		   .domain(d3.extent(data, function(d) { return d.BirthDate; }));

var y = d3.scale.linear()
                .range([height, 0])
				.domain(d3.extent(data,function(d) { return d.Handicap;}));

   var xAxis = d3.svg.axis().scale(x)
    .orient("bottom")
	//.tickFormat(d3.time.format("%Y-%m-%d %H:%M:%S"));
   .tickFormat(d3.time.format("%Y-%m-%d"));
	debugger;
var yAxis = d3.svg.axis().scale(y)
    .orient("left");
	 
	
	// Define the line
var valueline = d3.svg.line()
    .x(function(d) { return x(d.BirthDate); })
    .y(function(d) { return y(d.Handicap); });

// Define the div for the line graph tooltip
var div = d3.select("body").append("div")	
    .attr("class", "tooltip")				
    .style("opacity", 0);

	
var svg = d3.select("svg")
    .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
    .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    svg.append("g")         // Add the X Axis
        .attr("class", "x axis")
        .attr("transform", "translate(0," + height + ")")
        .call(xAxis)
		.selectAll("text")  
            .style("text-anchor", "end") 
            .attr("dx", "-.8em")
            .attr("dy", ".15em")
            .attr("transform", "rotate(-40)" );          //rotate the text label for x-axis
 
    svg.append("g")         // Add the Y Axis
        .attr("class", "y axis")
		.attr("id", "leftYAxis")
        .call(yAxis);
     
	
	  svg.append("path")      // Add the valueline path.
        .datum(data)
		 .attr("class", "line")
		 .attr("id", "line")
		.attr("d", valueline(data));
  

	// Add the scatterplot
    svg.selectAll("dot")	
        .data(data)
   
  //  .attr("class", "Dots")	
    .enter().append("circle")								
        .attr("r", 5)		
        .attr("cx", function(d) { return x(d.BirthDate); })		 
        .attr("cy", function(d) { return y(d.Handicap); })
        .attr("id", "dots")		
        .on("mouseover", function(d) {		
            div.transition()		
                .duration(200)		
                .style("opacity", .9);		
            div	.html( "Date of Birth:"+formatTime(d.BirthDate) + "<br/>"+ "Handicap:" + d.Handicap)	
                .style("left", (d3.event.pageX) + "px")		
                .style("top", (d3.event.pageY - 28) + "px");	
            })					
        .on("mouseout", function(d) {		
            div.transition()		
                .duration(500)		
                .style("opacity", 0);	
        });
	

		// Add the line title
		svg.append("text")
			.attr("x", width)
            .attr("y", margin.bottom + height)  
			.attr("class", "legend")
			.style("fill", "red")         
			.on("click", function(){
				// Determine if current line is visible
				
				var active   = line.active ? false : true ,
				  newOpacity = active ? 0 : 1;
				  
			//	var active1   = dots.active ? false : true ,
			//	  newOpacity = active ? 0 : 1;
				// Hide or show the elements
				d3.select("#line").style("opacity", newOpacity);
				d3.select("#leftYAxis").style("opacity", newOpacity);
				d3.selectAll("#dots").style("opacity", newOpacity);       //hide all dots within the line
				// Update whether or not the elements are active 
				line.active = active;
				//dots.active = active1;
			})
			.text("Line");	

	// now add titles to the axes
         svg.append("text")
    .attr("class", "x label")
   .attr("text-anchor", "end")
	//	.style("text-anchor","middle")
    .attr("x", width/2)
   .attr("y", margin.bottom + height)
   .text("Date & Time");
  // .style("font-size", 16px);
	    
		svg.append("text")
    .attr("class", "y label")
    .attr("text-anchor", "end")
	.attr("x", -90)
    .attr("y", -60)
//	.style("text-anchor","middle")
    .attr("dy", "1em")
    .attr("transform", "rotate(-90)")
    .text("Wind");

	 });	
 }
 </script>
 </body>

</html>	