<?php

include 'db.php';
	$query = "SELECT Score FROM Score";

    $result = mysql_query($query);

    if ( ! $query ) {
        echo mysql_error();
        die;
    }

    $data = array();

    for ($x = 0; $x < mysql_num_rows($result); $x++) {
        $data[] = mysql_fetch_assoc($result);
    }
	echo json_encode($data);  

$score_count = count($data);
$score_sum = array_sum($data);

$mean_average = $score_sum / $score_count;
echo $mean_average;

    mysql_close($conn);
?>
<script>
	
	
	function getAvg(numberArray) {
  return numberArray.reduce(function (p, c) {
  return p + c;
}) / numberArray.length;
}
getAvg($data);

</script>