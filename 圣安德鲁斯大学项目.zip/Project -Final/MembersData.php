<?php

	$servername = "zh29.host.cs.st-andrews.ac.uk:3306";
	$username = "zh29";
	$password = "V.Qs8Q6z2PYwCs";
	$dbname = "zh29_test2";

// Create connection
	$conn = mysql_connect($servername, $username, $password, $dbname);
	mysql_select_db("zh29_test2",$conn) or die ("no database");

	$query = "SELECT member_id,Handicap,first_name,last_name FROM Club_member Where Visibility = 1";

    $result = mysql_query($query);

    if ( ! $query ) {
        echo mysql_error();
        die;
    }

    $data = array();

    for ($x = 0; $x < mysql_num_rows($result); $x++) {
        $data[] = mysql_fetch_assoc($result);
    }
    
	echo json_encode($data);     

    mysql_close($conn);
?>