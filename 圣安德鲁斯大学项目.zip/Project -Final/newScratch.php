<?php
include("db.php");
if(isset($_POST['Newscratch'])&&($_POST['compeID']))
{
    $Newscratch = $_POST['Newscratch'];
    $compeID = $_POST['compeID'];
	
    $sql="UPDATE Competition1 SET Scratch ='$Newscratch' WHERE CompetitionID='$compeID'";	
	
	mysql_query($sql);
	$sql1 = " SET SQL_SAFE_UPDATES=0; 
    Update Score, Competition1
    Set Score.Differential = Score.Score-Competition1.Scratch 
     where Score.CompetitionID = Competition1.CompetitionID";
   mysql_query($sql1);
}

?>