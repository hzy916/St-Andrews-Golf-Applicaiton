<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<HTML>
<HEAD>
	<TITLE>Untitled</TITLE>

<SCRIPT type="text/javascript">
function chgSpan() {
    currentState = oSpan.isContentEditable;
    newState = !currentState;
    oSpan.contentEditable = newState;
 
    newState==false ? oBtn.innerText="Edit" :
        oBtn.innerText="Save"
}
</SCRIPT>
</HEAD>
<!--TOOLBAR_START-->
<!--TOOLBAR_EXEMPT-->
<!--TOOLBAR_END-->

<BODY>
<DIV class="body">
<P>Click the button to enable or disable SPAN content editing.</P>


<table border = 1>
<thead>
   <th>1</th>
   <th>2</th>
   <th>3</th>
</thead>
<td>Hello</td>
<td><SPAN ID="oSpan">ENTER SCORE HERE</SPAN></td>
<td><BUTTON ID="oBtn" onclick="chgSpan()">Edit</BUTTON></td>
</table>


<!-- START_PAGE_FOOTER -->
<BR><BR><BR>


<!-- END_PAGE_FOOTER -->
</DIV>
</BODY>
</HTML>
