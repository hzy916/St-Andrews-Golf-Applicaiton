<!doctype html>
<html class="no-js">
  <head>
    <meta charset="UTF-8">
    <title>Competition List</title>

    <!--IE Compatibility modes-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!--Mobile first-->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">

    <!-- Metis core stylesheet -->
    <link rel="stylesheet" href="assets/css/main.min.css">

    <!-- metisMenu stylesheet -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/metisMenu/1.1.3/metisMenu.min.css">
    <link rel="stylesheet" href="//cdn.datatables.net/plug-ins/3cfcc339e89/integration/bootstrap/3/dataTables.bootstrap.css">
	
	<SCRIPT type="text/javascript">
	function chgSpan(variable) {
		debugger;
		alert(variable);
		currentState = score119.isContentEditable;
		newState = !currentState;
		debugger;
		score119.contentEditable = newState;
		debugger;
		//newState==false ? edit119.innerText="EditNEW" :
			//edit119.innerText="Save"
			newState==false ? edit119.innerText="EditNEW" :
			writeToSql(memberid, newScore)
			alert("hello");
	}
	</SCRIPT>
	writeToSql(memberid, newScore)
	{
		//write to sql
	}
    <script>
      less = {
        env: "development",
        relativeUrls: false,
        rootpath: "../assets/"
      };
    </script>
    <link rel="stylesheet" href="assets/css/style-switcher.css">
    <link rel="stylesheet/less" type="text/css" href="assets/less/theme.less">
    <script src="//cdnjs.cloudflare.com/ajax/libs/less.js/2.2.0/less.min.js"></script>

    <script src="//cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
  </head>
  <body>
    <div class="bg-dark dk" id="wrap">
      <div id="top">

        <nav class="navbar navbar-inverse navbar-static-top">
          <div class="container-fluid">

            <!-- Brand and toggle get grouped for better mobile display -->
            <header class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                <span class="sr-only">Toggle navigation</span> 
                <span class="icon-bar"></span> 
                <span class="icon-bar"></span> 
                <span class="icon-bar"></span> 
              </button>
              <a href="index.html" class="navbar-brand">
                <!--STandrews Image-->
              </a> 
            </header>
            <div class="topnav">
              <div class="btn-group">
                <a data-placement="bottom" data-original-title="Fullscreen" data-toggle="tooltip" class="btn btn-default btn-sm" id="toggleFullScreen">
                  <i class="glyphicon glyphicon-fullscreen"></i>
                </a> 
              </div>
              <div class="btn-group">
              
                <a data-toggle="modal" data-original-title="Help" data-placement="bottom" class="btn btn-default btn-sm" href="#helpModal">
                  <i class="fa fa-question"></i>
                </a> 
              </div>
              <div class="btn-group">
                <a href="login.html" data-toggle="tooltip" data-original-title="Logout" data-placement="bottom" class="btn btn-metis-1 btn-sm">
                  <i class="fa fa-power-off"></i>
                </a> 
              </div>
              <div class="btn-group">
                <a data-placement="bottom" data-original-title="Show / Hide Left" data-toggle="tooltip" class="btn btn-primary btn-sm toggle-left" id="menu-toggle">
                  <i class="fa fa-bars"></i>
                </a> 
                <a data-placement="bottom" data-original-title="Show / Hide Right" data-toggle="tooltip" class="btn btn-default btn-sm toggle-right"> <span class="glyphicon glyphicon-comment"></span>  </a> 
              </div>
            </div>
            <div class="collapse navbar-collapse navbar-ex1-collapse">

              <!-- .nav -->
              <ul class="nav navbar-nav">
                <li> <a href="dashboard.php">Dashboard</a>  </li>
                <li class="active">
                  <a href="Test1.2.php">Tables</a> 
                </li>
                <li> <a href="fileManager.php">Report</a>  </li>
                <li class='dropdown '>
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    View Member List
                    <b class="caret"></b>
                  </a> 
                  <ul class="dropdown-menu">
                    <li> <a href="Test1.2.php">View</a>  </li>
                    <li> <a href="form-validation.html">Validation</a>  </li>
                   
                  </ul>
                </li>
              </ul><!-- /.nav -->
            </div>
          </div>
        </nav>
        <header class="head">
          <div class="search-bar">
           
          </div><!-- /.search-bar -->
          <div class="main-bar">
            <h3>
              <i class="fa fa-table"></i>&nbsp; Archive</h3>
          </div><!-- /.main-bar -->
        </header><!-- /.head -->
      </div><!-- /#top -->
      <div id="left">
        <div class="media user-media bg-dark dker">
          <div class="user-media-toggleHover">
            <span class="fa fa-user"></span> 
          </div>
          <div class="user-wrapper bg-dark">
            <a class="user-link" href="">
              <img class="media-object img-thumbnail user-img" alt="User Picture" src="assets/img/user.gif">
              <span class="label label-danger user-label">16</span> 
            </a> 
            <div class="media-body">
              <h5 class="media-heading">Archie</h5>
              <ul class="list-unstyled user-info">
                <li> <a href="">Administrator</a>  </li>
                <li>Last Access :
                  <br>
                  <small>
                    <i class="fa fa-calendar"></i>&nbsp;16 Mar 16:32</small> 
                </li>
              </ul>
            </div>
          </div>
        </div>

        <!-- #menu -->
        <ul id="menu" class="bg-blue dker">
          <li class="nav-header">Menu</li>
          <li class="nav-divider"></li>
          <li class="">
            <a href="dashboard.php">
              <i class="fa fa-dashboard"></i><span class="link-title">&nbsp;Dashboard</span> 
            </a> 
          </li>
         
        
          <li class="">
            <a href="javascript:;">
              <i class="fa fa-pencil"></i>
              <span class="link-title">
            Forms
	  </span> 
              <span class="fa arrow"></span> 
            </a> 
            <ul>
              <li>
                <a href="form.php">
                  <i class="fa fa-angle-right"></i>&nbsp; Add New Member </a> 
              </li>
              <li>
                <a href="Score.php">
                  <i class="fa fa-angle-right"></i>&nbsp; Enter Score </a> 
              </li>
            
            </ul>
          </li>
          <li class="active">
            <a href="Test1.2.php">
              <i class="fa fa-table"></i>
              <span class="link-title">Tables</span> 
            </a> 
          </li>
          <li>
            <a href="fileManager.php">
              <i class="fa fa-file"></i>
              <span class="link-title">
      File Manager
          </span> </a> 
          </li>
         
          <li>
            <a href="">
              <i class="fa fa-map-marker"></i><span class="link-title">
            Maps
          </span> </a> 
          </li>
          <li>
            <a href="">
              <i class="fa fa fa-bar-chart-o"></i>
              <span class="link-title">
            Charts
          </span> </a> 
          </li>
          <li>
            <a href="calendar.php">
              <i class="fa fa-calendar"></i>
              <span class="link-title">
            Calendar
          </span> </a> 
          </li>
          

          <li class="nav-divider"></li>
          <li>
            <a href="login.php">
              <i class="fa fa-sign-in"></i>
              <span class="link-title">
    Login Page
    </span> 
            </a> 
          </li>
         
           
          
            
        
        </ul><!-- /#menu -->
      </div><!-- /#left -->
      <?php
	echo"  <div id='content'>
       <div class='outer'>
       <div class='inner bg-light lter'>";

	$servername = "zh29.host.cs.st-andrews.ac.uk:3306";
	$username = "zh29";
	$password = "V.Qs8Q6z2PYwCs";
	$dbname = "zh29_test2";

// Create connection
	$conn = mysql_connect($servername, $username, $password, $dbname);
// Check connection
	if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
	}
	
		if(isset($_GET['id']))
		$id=$_GET['id'];
	  {
	  $viewComp=$_GET['id'];
	//filter all the players on the same competition.
mysql_select_db("zh29_test2");
	$sql =   "SELECT Score.memberID,
	Club_member.first_name,
	Club_member.last_name, 
	Club_member.Handicap, Club_member.BirthDate, Score.CompetitionDate
	FROM Club_member  join Score  WHERE Score.CompetitionDate = '$id' and Score.memberID=Club_member.member_id";

	 $viewComp = mysql_query($sql,$conn);
	
	 if($viewComp === FALSE) { 
    die(mysql_error()); // TODO: better error handling
} 
	
	
     ?>       
     <div class='row'>
              <div class='col-lg-12'>
                <div class='box'>
                  <header>
                    <div class='icons'>
                      <i class='fa fa-table'></i>
                    </div>
                    <h5>Players in Competition</h5>
                  </header>
                  <div id='collapse4' class='body'>
                    <table id='tableEdit' class='table table-bordered table-condensed table-hover table-striped'>
                      <thead>
                        <tr>
							<td colspan ='9' align='center'><h2>Players List</h2></td>
						</tr>
						<tr>
                          <th>Member ID</th>
						  <th>First Name</th>
                          <th>Last Name</th>
						  <th>Current Handicap</th>
						  <th>Date of Birth</th>
						  <th>Competition Date</th>
                          <th>Score</th>
						  <th>Button</th>
						  <th>Operation</th>
                        </tr>
				
                      </thead>
                      <tbody>
  <?php                    
while($record = mysql_fetch_array($viewComp)){  ?>
	<tr>
       <td><?php echo $record['memberID'] ?></td>
	   <td><?php echo $record['first_name'] ?></td>
		<td><?php echo $record['last_name']?></td>
		<td><?php echo $record['Handicap']?></td>
		<td><?php echo $record['BirthDate']?></td>
		<td><?php echo $record['CompetitionDate'] ?></td>
		<td><input type="text" ID=<?php echo 'score',$record['memberID'] ?>><?php echo 'score',$record['memberID'] ?></td>
		<td><BUTTON ID=<?php echo 'edit',$record['memberID'] ?> onclick="chgSpan(this.id)">EditNEW</BUTTON></td>
	    <!--<td><SPAN ID="oSpan">ENTER SCORE HERE</SPAN></td>
	    <td><BUTTON ID="oBtn" onclick="chgSpan()">Edit1</BUTTON></td>-->
		<td align='center'>
			 <a href=".php?id=<?php echo $record['Competition_Date'];?>"
    onclick="return confirm('Are you sure you wish to recover this Record?');">
    		<span class='delete' title='Delete'style="color:#ff00bf"> View Report </span></a>
		
</td>
	</tr>
<?php }
	  } ?>

                      </tbody>
                    </table>
					<input  type="button" name="enter" value="EnterScore"  onClick="EnterScore();" />
                  </div>
                </div>
              </div>
            </div>
   
      </div><!-- /#content -->
   </div>
    </div>
	
	

    <footer class="Footer bg-dark dker">
      <p>2016 &copy; St Andrews Ladies' Putting Club</p>
    </footer><!-- /#footer -->

   

    <!--jQuery -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/datatables/1.10.4/js/jquery.dataTables.min.js"></script>
    <script src="//cdn.datatables.net/plug-ins/3cfcc339e89/integration/bootstrap/3/dataTables.bootstrap.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery.tablesorter/2.18.4/js/jquery.tablesorter.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jqueryui-touch-punch/0.2.3/jquery.ui.touch-punch.min.js"></script>

    <!--Bootstrap -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.min.js"></script>

    <!-- MetisMenu -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/metisMenu/1.1.3/metisMenu.min.js"></script>

    <!-- Screenfull -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/screenfull.js/2.0.0/screenfull.min.js"></script>

    <!-- Metis core scripts -->
    <script src="assets/js/core.min.js"></script>

    <!-- Metis demo scripts -->
    <script src="assets/js/app.js"></script>
    <script>
      $(function() {
        Metis.MetisTable();
        Metis.metisSortable();
      });
    </script>
    <script src="assets/js/style-switcher.min.js"></script>
  </body>
  </html>