

<?php
$output = NULL;
if(isset($_POST['submit'])){
   //connect to database;	
	include("db.php");
	  $sql = "SELECT * FROM zh29_test2.Club_member";
//  echo $sql;
  $select = mysql_query($sql,$connection);  
   $search =mysql_real_escape_string(trim($_POST['search'])); 
   
   $find_results = mysql_query("SELECT * FROM `Club_member` WHERE `first_name` LIKE '%$search%' OR `last_name` LIKE '%$search%'");
   
   if($find_results->num_rows>0){
	    while($rows = $find_results->fetch_assoc()){
		    $id=$userrow['member_id'];
			$firstname=$userrow['first_name'];
			$lastname=$userrow['last_name'];
			$useremail=$userrow['email'];
			$birthDate=$userrow['BirthDate'];
			$phonenumber=$userrow['phone_number'];
			
			$output ="Member ID: $id<br />First Name: $firstname
			Last Name: $lastname <br /> Email: $useremail <br /> Date of Birth: $birthDate
			<br/> Phone Number: $phonenumber";
		}  
   }else{
	   echo "No results";
   }
}

?>


