<?php
  //ob_start();
  include("db.php");
  if(isset($_GET['id'])!="")
  {
  $delete=$_GET['id'];
 
  $delete = mysql_query("UPDATE Club_member set Visibility = 0 WHERE member_id = '$delete'");
  if($delete)
  {
	echo'<script language ="javascript">';
	echo'alert("Successfully Deleted!");location.href="memberList.php"';
	echo'</script>';
	//header("Location:index.php");
  }
  else
  {
	  echo mysql_error();
  }
  }
  ob_end_flush();
?>