<?php
//Find errors of blank page;
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 'On');
 ob_start();
  include("db.php");
  if(isset($_POST['submit'])!="")
  {
 // $memberID=$_POST['memberID'];
  $firstname=$_POST['firstname'];
  $lastname=$_POST['lastname'];
  $handicap=$_POST['handicap'];
  $usermail=$_POST['usermail'];
  $usermobile=$_POST['usermobile'];
  $birthdate=$_POST['birthdate'];

  
  //check whether handicap is null or not. So users are able to insert without handicap.
  if($handicap==null||$handicap == ""){
	  $update1="INSERT INTO Club_member(first_name,last_name,email,phone_number,BirthDate,created)VALUES
  ('$firstname','$lastname','$usermail','$usermobile','$birthdate',now())";
    $result = mysql_query($update1) or die(mysql_error());  	
  }else{
  
  $update="INSERT INTO Club_member(first_name,last_name,Handicap,email,phone_number,BirthDate,created)VALUES
  ('$firstname','$lastname','$handicap','$usermail','$usermobile','$birthdate',now())";	
  
  $handicap = "INSERT INTO handicapHistory(Handicap,created)VALUES('$handicap',now())";
	$result = mysql_query($update) or die(mysql_error());  
   $result1=mysql_query($handicap)or die(mysql_error());
  }	
 if($result)

  {
	echo'<script language ="javascript">';
	echo'alert("Successfully Added!");';
	
	echo 'location.href="memberList.php"';
	echo'</script>';
  }
  else
  {
	echo'<script language ="javascript">';
	echo'alert("Error!");';
	echo'</script>';
  }
 
  }
  
?>