<?php
 include("db.php");
if(isset($_POST['Avg'])&&($_POST['compID']))
{
    $Avg = $_POST['Avg'];
    $compID = $_POST['compID'];
	echo $Avg;
    $updateScratch="UPDATE Competition1 SET Scratch ='$Avg' WHERE CompetitionID='$compID'";	
	
	

	mysql_query($updateScratch);
	
	$sql = " 
    Update Score, Competition1
    Set Score.Differential = Score.Score-Competition1.Scratch 
     where Score.CompetitionID = Competition1.CompetitionID ";
	 echo $sql;
 mysql_query($sql);
}

?>



		
 