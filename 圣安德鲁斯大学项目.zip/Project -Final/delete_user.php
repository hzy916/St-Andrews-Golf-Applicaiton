<?php
 include("db.php");
$rowCount = count($_POST["users"]);
for($i=0;$i<$rowCount;$i++) {
	$sql ="UPDATE Club_member SET Visibility =0 where member_id='" . $_POST["users"][$i] . "'";
	
mysql_query($sql);
}
header("Location:memberList.php");
?>