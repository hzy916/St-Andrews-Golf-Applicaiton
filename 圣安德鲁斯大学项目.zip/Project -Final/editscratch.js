function Click(compe){
	var newscratch = $('#'+compe).val();
	console.log(newscratch);
	$.ajax({
	type: "POST",
                    url: 'newScratch.php',
                    data: {Newscratch: newscratch,compeID:compe},
                    success: function(data)
                    {
                        alert("success!");
                    }
	
})
	
}

