//TO get all the scores in one competition


var MyRows = $('table#dataTable').find('tbody').find('tr');
console.log(MyRows);
var empty = [];
for (var i = 0; i < MyRows.length; i++) {


var score = $(MyRows[i]).find('td:eq(7)').find('input:eq(1)').val();
empty.push(parseInt(score));
}
console.log(empty);


// get all the players' id in one competition
var Rows = $('table#dataTable').find('tbody').find('tr');
console.log(Rows);
var memberid = [];
for (var i = 0; i < Rows.length; i++) {


var ids = $(Rows[i]).find('td:eq(0)').text();
memberid.push(parseInt(ids));
}
console.log(memberid);



//To combine the two arrays into a object;
/*
var data=new Object();
for(var i=0;i<memberid.length;i++){
 
  data[i] = new Array();
  data[i]["member_id"]=memberid[i];
  data[i]["Handicap"]=empty[i];
}

console.log(data);

*/
//To check whether there are empty score, if all scores are entered, the scratch will be calculated.

function getScratch(){
function findNaN(empty){	
  for(i = 0; i<empty.length; i++){
	 var item =  empty[i];
     if(isNaN(item)){
		   return true;
     }
  }
  return false;
}

if (findNaN(empty)==false){
  getAvg(empty);
}    

//calculate scratch
function getAvg(empty){
var total = 0;
for(var i = 0; i < empty.length; i++) {
    total += empty[i];
}
var avg = Math.round(total / empty.length);

console.log(avg);

document.getElementById("p1").innerHTML = "<b>Scratch:</b>"+avg;

var compid = $(MyRows[0]).find('td:eq(7)').find('input:eq(3)').val();
console.log(parseInt(compid));

//using AJAX to send scratch and competition id to scratch.php, in order to update scratch column in competition1 table.
$.ajax({
	type: "POST",
                    url: 'Scratch.php',
                    data: {Avg: avg,compID:compid},
                    success: function(data)
                    {
                        alert("Scratch is calculated!");
                    }
	
})
}
}