<?php

include('db.php');
/*
if(isset($_GET['id']))
{*/if(isset($_GET['enterhandicap']))
  {
   
    $ehandicap=$_GET['ehandicap'];
	$playerid=$_GET['playerid'];
	
  $inserted="UPDATE Club_member SET Handicap ='$ehandicap' WHERE member_id='$playerid'";

$result= mysql_query($inserted);
  if($result)
  {  
   
	header('Location: ' . $_SERVER['HTTP_REFERER']);
	
  }
}
?>