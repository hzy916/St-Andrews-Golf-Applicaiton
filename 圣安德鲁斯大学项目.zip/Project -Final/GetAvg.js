


<script>

var numberArray=[47,47,48,48,49,49,50,50,51,51,51,
                 52,52,52,52,52,53,53,53,53,54,54,55,55,55,56], thisTotal=0,thisAverage=0;
// add elements of array together
 for(var i=0;i<numberArray.length;i++)
  {thisTotal+=numberArray[i];}
// calculate average
 thisAverage=(thisTotal/numberArray.length);
// display result
 alert(thisAverage);


var numberArray=[47,47,48,48,49,49,50,50,51,51,51,
                 52,52,52,52,52,53,53,53,53,54,54,55,55,55,56];
function getAvg(numberArray) {
  return numberArray.reduce(function (p, c) {
  return p + c;
}) / numberArray.length;
}

console.log(getAvg(numberArray))


</script>

$score_count = count($data);
$score_sum = array_sum($data);

$mean_average = $score_sum / $score_count;
echo $mean_average;