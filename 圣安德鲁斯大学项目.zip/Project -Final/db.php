<?php

error_reporting(E_ALL ^ E_DEPRECATED);
    $servername = "zh29.host.cs.st-andrews.ac.uk:3306";
	$username = "zh29";
	$password = "V.Qs8Q6z2PYwCs";
	$dbname = "zh29_test2";

// Create connection
	$conn = mysql_connect($servername, $username, $password, $dbname);
	mysql_select_db("zh29_test2",$conn) or die ("no database");
// Check connection
	if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
	}
	
?>